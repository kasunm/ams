package lk.empire.ams.model.enums;



/**
 * <p>Title         : InquiryAction Enum
 * <p>Project       : Ams : Apartment management system for empire apartments
 * <p>Description   :
 *
 * @author Kasun Madurasinghe
 * @version 1.0
 */
public enum InquiryAction {

    Pending,Planned,Done,Rejected
}
