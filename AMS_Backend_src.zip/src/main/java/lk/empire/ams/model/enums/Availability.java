package lk.empire.ams.model.enums;



/**
 * <p>Title         : Availability Enum
 * <p>Project       : Ams : Apartment management system for empire apartments
 * <p>Description   :
 *
 * @author Kasun Madurasinghe
 * @version 1.0
 */
public enum Availability {

    Available,Unavailable
}
