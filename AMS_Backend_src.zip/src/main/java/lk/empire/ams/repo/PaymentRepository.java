package lk.empire.ams.repo;

import lk.empire.ams.model.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import lk.empire.ams.model.enums.*;
import java.util.List;
import java.time.*;

/**
 * <p>Title         : Payment Repository
 * <p>Project       : Ams : Apartment management system for empire apartments
 * <p>Description   : Repository support for Payment. A Payment for of an apartment or related activity
 *
 * @author Kasun Madurasinghe
 * @version 1.0
 */
@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {

 List<Payment> findPaymentsByClient_Id(Long client);
List<Payment> findAllByStatus(PaymentStatus status);
List<Payment> findAllByDueDate(LocalDate dueDate);
List<Payment> findAllByUnit_Id(Long unit);


}
